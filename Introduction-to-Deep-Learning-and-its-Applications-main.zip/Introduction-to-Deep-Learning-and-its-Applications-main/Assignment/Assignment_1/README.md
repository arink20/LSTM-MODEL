# Stamatics-Summer-Project-2022

Assignment - 1
