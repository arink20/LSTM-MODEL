# Stamatics-Summer-Project-2022
We will cover the basics of Linear Algebra and related concepts in Deep Learning and Neural Networks and then implement models based on the concepts learned.

The Recourses will be updated on weekly basis on this [link](https://famous-neon-d70.notion.site/Introduction-to-Deep-Learning-and-its-Applications-e2d0fe44f5204c1cbc0b0068626a85ae).